const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express()

app.use(function(req, res, next) {
     res.setHeader('Access-Control-Allow-Origin', '*');
     res.setHeader('Access-Control-Allow-Methods', '*');
     res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
      next()
})
app.use(bodyParser.json());

const PUERTO = 3307

const conexion = mysql.createConnection(
    {
        host:'localhost',
        database:'farming',
        user:'root',
        password:''
}
)
app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto ${PUERTO}`);
})

conexion.connect(error => {
    if(error) throw error
    console.log('Conexión exitosa a la base de datos');
})


app.get('/', (req, res) => {
    res.send('API')
})

//tabla usuarios/*
app.get('/usuario', (req, res) => {
    const query = `SELECT * FROM usuario`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/usuario', (req,res) => {
    let {
        id_usuario,roles_idroles, Num_local
    } = req.body

    const query = `INSERT INTO usauario VALUES (${id_usuario},${roles_idroles},${Num_local}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el anuncio`)
         }
})
})

app.put('/usuario/:id_usuario', (req, res) => {
    const { id_usuario } = req.params
    let {
        roles_idroles, Num_local
    } = req.body

    const query = `UPDATE usuario SET roles_idroles='${roles_idroles}', Num_local='${Num_local}' WHERE id_usuario=${id_usuario}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el anuncio`)
})
})

app.delete('/usuario_eliminar/:id_usuario', (req, res) => {
    const { id_usuario } = req.params

    const query = `DELETE from usuario WHERE id_usuario=${id_usuario}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
 })
})

app.get('/usuario/:id_usuario', (req,res) => {
    const {id_tipo_doc} = req.params
 
     const query =` select * from usuario  where id_usuario = ${id_usuario}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})

// tabla tipo_doc/*
app.get('/Tipo_Doc ', (req, res) => {
    const query = `SELECT * FROM Tipo_Doc `
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/Tipo_Doc', (req,res) => {
    let {
        id_tipo_doc, Desc_Docu
    } = req.body

    const query = `INSERT INTO Tipo_Doc VALUES (${id_tipo_doc},'${ Desc_Docu}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el anuncio`)
         }
})
})

app.put('/Tipo_Doc/:id_tipo_doc', (req, res) => {
    const { id_tipo_doc } = req.params
    let {
        Desc_Docu
    } = req.body

    const query = `UPDATE Tipo_Doc SET Desc_Docu='${Desc_Docu}' WHERE id_tipo_doc=${id_tipo_doc}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el anuncio`)
})
})

app.delete('Tipo_Doc_eliminar/:id_tipo_doc', (req, res) => {
    const { id_tipo_doc } = req.params

    const query = `DELETE from Tipo_Doc WHERE id_tipo_doc=${id_tipo_doc}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
 })
})

app.get('/Tipo_Doc/:id_tipo_doc', (req,res) => {
    const {id_tipo_doc} = req.params
 
     const query =` select * from Tipo_Doc where id_tipo_doc = ${id_tipo_doc}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})

//persona/*
app.get('/persona', (req, res) => {
    const query = `SELECT * FROM persona`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/persona', (req,res) => {
    let {
        id_persona,Tipo_doc_id_tipo_doc, Nombre1,Nombre2,Apellido1,Apellido2,Num_Doc, Correo,Tel_Cel,Direccion,Usuario
    } = req.body

    const query = `INSERT INTO persona VALUES (${id_persona},'${Tipo_doc_id_tipo_doc}','${Nombre1}','${Nombre2}','${Apellido1}','${Apellido2}','${Num_Doc}','${Correo}','${Tel_Cel}','${Direccion}','${Usuario}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el anuncio`)
         }
})
})

app.put('/persona/:id_persona', (req, res) => {
    const {  id_persona } = req.params
    let {
        Tipo_doc_id_tipo_doc, Nombre1,Nombre2,Apellido1,Apellido2,Num_Doc, Correo,Tel_Cel,Direccion,Usuario
        
    } = req.body

    const query = `UPDATE persona SET Tipo_doc_id_tipo_doc=${Tipo_doc_id_tipo_doc},Nombre1='${Nombre1}',Nombre2='${Nombre2}',Apellido1='${Apellido1}',Apellido2='${Apellido2}',Num_Doc'=${Num_Doc}',Correo='${Correo}',Tel_Cel='${Tel_Cel}',Direccion='${Direccion}',usario='${Usuario}' WHERE  id_persona=${ id_persona}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el anuncio`)
})
})

app.delete('persona_eliminar/:id_persona', (req, res) => {
    const { id_persona } = req.params

    const query = `DELETE from persona WHERE id_persona=${id_persona}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
})
})

app.get('/persona/:id_persona', (req,res) => {
    const {id_persona} = req.params
 
     const query =` select * from persona where id_persona = ${id_persona}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})

//roles/*
app.get('/Roles ', (req, res) => {
    const query = `SELECT * FROM  Roles   `
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/Roles', (req,res) => {
    let {
        id_rol,persona_Tipo_doc_id_tipo_doc,persona_idpersona,Estado_rol,Nom_rol
    } = req.body

    const query = `INSERT INTO Roles VALUES (${id_rol},'${persona_Tipo_doc_id_tipo_doc}','${persona_idpersona}','${Estado_rol}','${Nom_rol}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el anuncio`)
         }
})
})

app.put('/Roles/:id_rol', (req, res) => {
    const {  id_rol } = req.params
    let {
        persona_Tipo_doc_id_tipo_doc,persona_idpersona,Estado_rol,Nom_rol
        
    } = req.body

    const query = `UPDATE Roles SET  persona_Tipo_doc_id_tipo_doc=${ persona_Tipo_doc_id_tipo_doc},persona_idpersona='${persona_idpersona}',Estado_rol='${Estado_rol}',Nom_rol='${Nom_rol}' WHERE id_rol=${id_rol}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el anuncio`)
})
})

app.delete('Roles_eliminar/:id_rol', (req, res) => {
    const { id_rol } = req.params

    const query = `DELETE from Roles WHERE id_persona=${id_rol}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
})
})

app.get('/Roles/:id_rol', (req,res) => {
    const {id_rol} = req.params
 
     const query =` select * from Roles where id_rol=${id_rol}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})

//productos_usuario/*
app.get('/productos_usuario', (req, res) => {
    const query = `SELECT * FROM productos_usuario`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/productos_usuario', (req,res) => {
    let {
     id_productos_usuario,usuario_idusuario,peso_idpeso,categoria_idcategoria,Nom_producto,Cantidad,Url_img_pro
    } = req.body

    const query = `INSERT INTO productos_usuario VALUES (${id_productos_usuario},'${usuario_idusuario}','${peso_idpeso}','${categoria_idcategoria}','${Nom_producto}','${Cantidad}','${Url_img_pro}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el productos_usuario'`)
         }
})
})

app.put('/productos_usuario/:id_productos_usuario', (req, res) => {
    const {id_productos_usuario } = req.params
    let {
        usuario_idusuario,peso_idpeso,categoria_idcategoria,Nom_producto,Cantidad,Url_img_pro
        
    } = req.body

    const query = `UPDATE productos_usuario SET  usuario_idusuario=${ usuario_idusuario},peso_idpeso='${peso_idpeso}',categoria_idcategoria='${categoria_idcategoria}',Nom_producto='${Nom_producto}',Cantidad='${Cantidad}',Url_img_pro='${Url_img_pro}' WHERE id_productos_usuario=${id_productos_usuario }`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el productos_usuario `)
})
})

app.delete('productos_usuario/:id_productos_usuario', (req, res) => {
    const { id_productos_usuario } = req.params

    const query = `DELETE from persona WHERE id_productos_usuario=${id_productos_usuario}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
})
})

app.get('/productos_usuario/:id_productos_usuario', (req,res) => {
    const {id_productos_usuario} = req.params
 
     const query =` select * from productos_usuario where id_productos_usuario=${id_productos_usuario}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})

//Reserva/*
app.get('/Reserva', (req, res) => {
    const query = `SELECT * FROM Reserva`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/Reserva', (req,res) => {
    let {
        id_reserva,productos_por_usuario_idproductos_usuario,p_beneficiaria_idp_beneficiaria,Fecha,Duracion
    } = req.body

    const query = `INSERT INTO Reserva VALUES (${id_reserva},'${Tipo_doc_id_tipo_doc}','${productos_por_usuario_idproductos_usuario}','${p_beneficiaria_idp_beneficiaria}','${Fecha}','${Duracion}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el anuncio`)
         }
})
})

app.put('/Reserva/:id_reserva', (req, res) => {
    const { id_reserva } = req.params
    let {
        productos_por_usuario_idproductos_usuario,p_beneficiaria_idp_beneficiaria,Fecha,Duracion
        
    } = req.body

    const query = `UPDATE Reserva SET productos_por_usuario_idproductos_usuario=${productos_por_usuario_idproductos_usuario},p_beneficiaria_idp_beneficiaria='${p_beneficiaria_idp_beneficiaria}',Fecha='${Fecha}',Duracion='${Duracion}' WHERE id_reserva=${id_reserva}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el anuncio`)
})
})

app.delete('Reserva_eliminar/:id_reserva', (req, res) => {
    const { id_reserva } = req.params

    const query = `DELETE from Reserva WHERE id_reserva=${id_reserva}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
})
})

app.get('/Reserva/:id_reserva', (req,res) => {
    const {id_persona} = req.params
 
     const query =` select * from Reserva where id_reserva=${id_reserva}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})

//peso/*
app.get('/peso', (req, res) => {
    const query = `SELECT * FROM peso`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/peso', (req,res) => {
    let {
        id_peso,Desc_peso 
    } = req.body

    const query = `INSERT INTO peso VALUES (${id_peso},'${Desc_peso}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el anuncio`)
         }
})
})

app.put('/peso/:id_peso,', (req, res) => {
    const { id_peso } = req.params
    let {
        Desc_peso 
    } = req.body

    const query = `UPDATE peso SET Desc_peso ='${Desc_peso }' WHERE id_peso=${id_peso}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el anuncio`)
})
})

app.delete('peso_eliminar/:id_peso', (req, res) => {
    const {id_peso} = req.params

    const query = `DELETE from peso WHERE id_peso=${id_peso}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
 })
})

app.get('/peso/:id_peso', (req,res) => {
    const {id_peso} = req.params
 
     const query =` select * from peso where id_peso=${id_peso}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})

//Categoria/*
app.get('/Categoria', (req, res) => {
    const query = `SELECT * FROM Categoria`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
    }
})
})

app.post('/Categoria', (req,res) => {
    let {
        id_categoria,Nom_categoria
    } = req.body

    const query = `INSERT INTO Categoria VALUES (${id_categoria},'${Nom_categoria}')`
        conexion.query(query, (error) => {
            if(error) {
                res.json('Un error ocurrió. Por favor, inténtelo nuevamentente')
            }
            else {
                res.json(`Se agregó correctamente el anuncio`)
         }
})
})

app.put('/Categoria/:id_categoria,', (req, res) => {
    const { id_categoria } = req.params
    let {
        Nom_categoria
    } = req.body

    const query = `UPDATE Categoria SET Nom_categoria='${Nom_categoria}' WHERE id_categoria=${id_categoria}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se actualizó correctamente el anuncio`)
})
})

app.delete('Categoria_eliminar/:id_categoria', (req, res) => {
    const {id_categoria} = req.params

    const query = `DELETE from Categoria WHERE id_categoria=${id_categoria}`
    conexion.query(query, (error) => {
        if(error) return console.error(error.message)

        res.json(`Se eliminó correctamente`)
 })
})

app.get('/Categoria/:id_categoria', (req,res) => {
    const {id_peso} = req.params
 
     const query =` select * from Categoria where id_categoria=${id_categoria}`
 
   conexion.query(query, (error, resultado) => {
    if(error) return console.error(error.message)
 
         console.log(resultado)
 
         if(resultado.length > 0) {
             res.json(resultado)
         } else {
             res.json(`No hay registros`)
}
 })
})


